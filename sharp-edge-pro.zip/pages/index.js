import { useState, useEffect, useCallback, useRef } from 'react'
import Head from 'next/head'
import { XG_DB, NHL_TEAMS, NBA_TEAMS, ELO_BY_SURFACE, ODDS_API_SPORTS } from '../lib/data'
import { evCalc, toImplied, kellyFraction, clvCalc, removeVig } from '../lib/models'

// ── SPORT CONFIG ───────────────────────────────────────────────────
const SPORT_TABS = [
  { key: 'football', label: '⚽ FÚTBOL',  color: '#00ff88' },
  { key: 'tennis',   label: '🎾 TENIS',   color: '#ffd700' },
  { key: 'nhl',      label: '🏒 NHL',     color: '#00bfff' },
  { key: 'nba',      label: '🏀 NBA',     color: '#ff6b35' },
]

const PAGE_TABS = [
  { key: 'scanner',   label: '◈ SCANNER',  icon: '🔍' },
  { key: 'model',     label: '⚡ MODELO',   icon: '🧮' },
  { key: 'tracker',   label: '📊 TRACKER',  icon: '📊' },
  { key: 'portfolio', label: '💼 PORTF.',   icon: '💼' },
]

const SCAN_SPORTS = [
  { key: 'soccer_spain_la_liga',      label: 'LaLiga',    type: 'soccer' },
  { key: 'soccer_epl',                label: 'Premier',   type: 'soccer' },
  { key: 'soccer_germany_bundesliga', label: 'Bundesliga',type: 'soccer' },
  { key: 'soccer_italy_serie_a',      label: 'Serie A',   type: 'soccer' },
  { key: 'soccer_uefa_champs_league', label: 'Champions', type: 'soccer' },
  { key: 'soccer_sweden_allsvenskan', label: 'Allsvenskan',type:'soccer' },
  { key: 'icehockey_nhl',             label: 'NHL',       type: 'hockey' },
  { key: 'basketball_nba',            label: 'NBA',       type: 'basketball' },
]

// ── HELPERS ────────────────────────────────────────────────────────
const G='#00ff88',Y='#ffd700',B='#00bfff',P='#a855f7',R='#ff4444',O='#ff6b35'
const evColor  = v => v > 15 ? G : v > 8 ? Y : O
const confLabel = v => v > 15 ? 'ALTO' : v > 8 ? 'MEDIO' : 'BAJO'
const fmtEV  = v => `${v >= 0 ? '+' : ''}${v.toFixed(2)}%`
const fmtPnl = v => `${v >= 0 ? '+' : ''}€${Math.abs(v).toFixed(0)}`
const fmtPct = v => `${v >= 0 ? '+' : ''}${v.toFixed(1)}pp`

function SBox({ label, val, color = '#888', sm = false }) {
  return (
    <div className="sbox">
      <div className="sbox-label">{label}</div>
      <div className="sbox-val" style={{ color, fontSize: sm ? 10 : 11 }}>{val}</div>
    </div>
  )
}

function EVBar({ ev, color }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3, fontSize: 8 }}>
        <span style={{ color: '#1a1a1a' }}>VALOR ESPERADO</span>
        <span style={{ color, fontWeight: 700 }}>{fmtEV(ev)}</span>
      </div>
      <div className="bar-track">
        <div className="bar-fill" style={{ width: `${Math.min(Math.abs(ev)/30*100,100)}%`, background: color }} />
      </div>
    </div>
  )
}

function CLVBar({ clv }) {
  const c = clv >= 0 ? G : R
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3, fontSize: 8 }}>
        <span style={{ color: '#1a1a1a' }}>CLV vs PINNACLE NO-VIG</span>
        <span style={{ color: c, fontWeight: 700 }}>{fmtPct(clv)}</span>
      </div>
      <div className="bar-track">
        <div className="bar-fill" style={{ width: `${Math.min(Math.abs(clv)/15*100,100)}%`, background: c }} />
      </div>
    </div>
  )
}

function Label({ children, color = '#1a1a1a' }) {
  return <div style={{ fontSize: 8, color, marginBottom: 4, letterSpacing: '.5px' }}>{children}</div>
}

function Inp({ value, onChange, type = 'number', placeholder, style = {} }) {
  return (
    <input
      className="inp"
      value={value}
      onChange={e => onChange(e.target.value)}
      type={type}
      step="0.01"
      placeholder={placeholder}
      style={style}
    />
  )
}

function Sel({ value, onChange, options }) {
  return (
    <select className="inp" value={value} onChange={e => onChange(e.target.value)}>
      <option value="">Seleccionar...</option>
      {options.map(o => <option key={o} value={o}>{o}</option>)}
    </select>
  )
}

// ── PICK CARD ──────────────────────────────────────────────────────
function PickCard({ alert: a, bankroll, onAddTracker, delay = 0 }) {
  const [open, setOpen] = useState(false)
  const ec = evColor(a.ev)

  return (
    <div className="pick-card fade-up" style={{ animationDelay: `${delay}s`, borderLeft: `4px solid ${ec}` }}>
      <div className="pick-header" onClick={() => setOpen(!open)}>
        <div style={{ display: 'flex', gap: 5, marginBottom: 6, flexWrap: 'wrap', alignItems: 'center' }}>
          <span className="tag" style={{ background: `${ec}15`, color: ec, borderColor: `${ec}35` }}>
            {confLabel(a.ev)} · {fmtEV(a.ev)}
          </span>
          <span className="tag" style={{ background: '#111', color: '#333', borderColor: '#222' }}>
            {a.date} {a.time}
          </span>
          <span className="tag" style={{ background: '#111', color: '#2a2a2a', borderColor: '#1a1a1a' }}>
            {a.src?.toUpperCase()}
          </span>
        </div>
        <div style={{ color: '#555', fontSize: 9, marginBottom: 2 }}>{a.match}</div>
        <div style={{ color: '#ddd', fontSize: 14, fontWeight: 700, marginBottom: 10, lineHeight: 1.3 }}>{a.market}</div>
        <div className="g4">
          <SBox label="Cuota"    val={a.dec.toFixed(2)}       color="#ccc" />
          <SBox label="DC Prob"  val={`${a.prob.toFixed(1)}%`}color={B}   />
          <SBox label="EV"       val={fmtEV(a.ev)}            color={ec}  />
          <SBox label="CLV"      val={fmtPct(a.clvDC)}        color={a.clvDC >= 0 ? G : R} />
        </div>
      </div>

      {open && (
        <div className="pick-body" style={{ paddingTop: 11 }}>
          <div className="g3" style={{ marginBottom: 10 }}>
            <SBox label="Implícita"  val={`${a.imp.toFixed(1)}%`}      color="#555" />
            <SBox label="Pin no-vig" val={`${a.nvProb.toFixed(1)}%`}    color={P}   />
            <SBox label="¼ Kelly"    val={`€${kellyFraction(a.prob, a.dec, bankroll)}`} color={Y} />
          </div>
          {a.hxg && (
            <div className="g4" style={{ marginBottom: 10 }}>
              <SBox label="xG Local"    val={a.hxg}  color={G}    sm />
              <SBox label="xG Visit."   val={a.axg}  color={B}    sm />
              <SBox label="Córners exp" val={a.hCorn && a.aCorn ? `${+(a.hCorn+a.aCorn).toFixed(1)}` : '—'} color={P} sm />
              <SBox label="Tarjetas exp"val={a.expCards || '—'}     color={O}    sm />
            </div>
          )}
          <EVBar ev={a.ev} color={ec} />
          <CLVBar clv={a.clvDC} />
          <button
            className="btn-secondary"
            style={{ width: '100%', marginTop: 2 }}
            onClick={() => onAddTracker({ match: a.match, market: a.market, myOdds: a.dec, stake: kellyFraction(a.prob, a.dec, bankroll) })}
          >
            + AÑADIR AL CLV TRACKER
          </button>
        </div>
      )}
    </div>
  )
}

// ── SCANNER PAGE ───────────────────────────────────────────────────
function ScannerPage({ bankroll, onAddTracker }) {
  const [apiKey,   setApiKey]   = useState(() => typeof window !== 'undefined' ? localStorage.getItem('se_key') || '' : '')
  const [selected, setSelected] = useState(['soccer_epl', 'soccer_spain_la_liga'])
  const [minEV,    setMinEV]    = useState(5)
  const [scanning, setScanning] = useState(false)
  const [alerts,   setAlerts]   = useState([])
  const [log,      setLog]      = useState([])
  const [done,     setDone]     = useState(false)
  const [remaining,setRemaining]= useState(null)
  const [filter,   setFilter]   = useState('ALL')
  const logRef = useRef(null)

  const saveKey = key => {
    setApiKey(key)
    if (typeof window !== 'undefined') localStorage.setItem('se_key', key)
  }

  const scan = async () => {
    if (!apiKey.trim()) return
    setScanning(true); setAlerts([]); setLog([]); setDone(false)

    const sports = SCAN_SPORTS.filter(s => selected.includes(s.key))

    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: apiKey.trim(), sports, minEV, bankroll }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setAlerts(data.alerts)
      setLog(data.log || [])
      setRemaining(data.remaining)
    } catch (e) {
      setLog(prev => [...prev, `✗ Error: ${e.message}`])
    }

    setScanning(false); setDone(true)
    setTimeout(() => { if (logRef.current) logRef.current.scrollTop = 99999 }, 50)
  }

  const toggle = key => setSelected(prev => prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key])

  const cats   = ['ALL', ...new Set(alerts.map(a => a.market.includes('Goles')||a.market.includes('Over')||a.market.includes('Under')||a.market==='BTTS Sí'||a.market==='BTTS No' ? 'GOLES' : a.market.includes('Empate')||a.market.match(/^[12] —/) ? '1X2' : 'OTROS'))]
  const visible = filter === 'ALL' ? alerts : alerts.filter(a => {
    const cat = a.market.includes('Goles')||a.market.includes('Over')||a.market.includes('Under')||a.market==='BTTS Sí'||a.market==='BTTS No' ? 'GOLES' : a.market.includes('Empate')||a.market.match(/^[12] —/) ? '1X2' : 'OTROS'
    return cat === filter
  })

  return (
    <div>
      {/* API Key */}
      <div className="card">
        <div className="card-title" style={{ color: G }}>THE ODDS API — ACCESO A PINNACLE EN TIEMPO REAL</div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          <input
            className="inp"
            type="password"
            value={apiKey}
            onChange={e => saveKey(e.target.value)}
            placeholder="Pega tu API key aquí (gratis en the-odds-api.com)"
            style={{ flex: 1 }}
          />
          <a href="https://the-odds-api.com" target="_blank" rel="noreferrer"
            style={{ display: 'flex', alignItems: 'center', padding: '0 12px', background: '#111', border: '1px solid #1a1a1a', borderRadius: 5, color: Y, fontSize: 8, letterSpacing: 1, whiteSpace: 'nowrap', textDecoration: 'none' }}>
            GRATIS →
          </a>
        </div>
        {apiKey && <div style={{ fontSize: 8, color: '#2a5a2a' }}>✓ API key lista{remaining !== null ? ` · ${remaining} llamadas restantes` : ''}</div>}
        {!apiKey && <div style={{ fontSize: 8, color: '#555' }}>500 llamadas/mes gratis · Pinnacle + Bet365 + 40 casas · 40 deportes</div>}
      </div>

      {/* Sport selector */}
      <div className="card">
        <div className="card-title">DEPORTES A ESCANEAR</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
          {SCAN_SPORTS.map(s => (
            <button
              key={s.key}
              className={`filter-pill ${selected.includes(s.key) ? 'active' : ''}`}
              onClick={() => toggle(s.key)}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* EV + Play */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 12, alignItems: 'center' }}>
        <span style={{ color: '#1a1a1a', fontSize: 8, flexShrink: 0 }}>EV MÍN:</span>
        <button onClick={() => setMinEV(v => Math.max(2, v-1))} style={{ background: '#111', border: '1px solid #161616', color: '#555', borderRadius: 4, width: 26, height: 26, fontSize: 16, flexShrink: 0 }}>−</button>
        <span style={{ color: G, fontSize: 15, fontWeight: 700, minWidth: 40, textAlign: 'center', flexShrink: 0 }}>+{minEV}%</span>
        <button onClick={() => setMinEV(v => Math.min(25, v+1))} style={{ background: '#111', border: '1px solid #161616', color: '#555', borderRadius: 4, width: 26, height: 26, fontSize: 16, flexShrink: 0 }}>+</button>
      </div>

      <button className="btn-primary" onClick={scan} disabled={scanning || !apiKey.trim() || !selected.length} style={{ marginBottom: 12 }}>
        {scanning
          ? <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}><span className="spinner" />ESCANEANDO PINNACLE...</span>
          : `▶  PLAY — ${selected.length} DEPORTE${selected.length !== 1 ? 'S' : ''}`}
      </button>

      {/* Log terminal */}
      {log.length > 0 && (
        <div ref={logRef} style={{ background: '#040404', border: '1px solid #0d0d0d', borderRadius: 7, padding: '10px 12px', maxHeight: 140, overflowY: 'auto', marginBottom: 14, fontFamily: 'monospace' }}>
          {log.map((l, i) => (
            <div key={i} style={{ fontSize: 9, lineHeight: 1.9, color: l.startsWith('🚨') ? G : l.startsWith('✗') ? R : '#1e1e1e' }}>
              {l}
            </div>
          ))}
        </div>
      )}

      {/* Summary */}
      {done && alerts.length > 0 && (
        <>
          <div className="g3" style={{ marginBottom: 12 }}>
            <div className="sum-card" style={{ background: '#0a0a0a', border: '1px solid #161616', borderRadius: 7, padding: '10px 8px', textAlign: 'center' }}>
              <div className="sum-label" style={{ color: '#1a1a1a', fontSize: 7, marginBottom: 3 }}>VALUE BETS</div>
              <div style={{ color: G, fontSize: 18, fontWeight: 700 }}>{alerts.length}</div>
            </div>
            <div className="sum-card" style={{ background: '#0a0a0a', border: '1px solid #161616', borderRadius: 7, padding: '10px 8px', textAlign: 'center' }}>
              <div className="sum-label" style={{ color: '#1a1a1a', fontSize: 7, marginBottom: 3 }}>EV PROMEDIO</div>
              <div style={{ color: Y, fontSize: 18, fontWeight: 700 }}>+{(alerts.reduce((s,a) => s+a.ev,0)/alerts.length).toFixed(1)}%</div>
            </div>
            <div className="sum-card" style={{ background: '#0a0a0a', border: '1px solid #161616', borderRadius: 7, padding: '10px 8px', textAlign: 'center' }}>
              <div className="sum-label" style={{ color: '#1a1a1a', fontSize: 7, marginBottom: 3 }}>MEJOR EV</div>
              <div style={{ color: B, fontSize: 18, fontWeight: 700 }}>+{Math.max(...alerts.map(a=>a.ev)).toFixed(1)}%</div>
            </div>
          </div>

          {/* Category filter */}
          <div style={{ display: 'flex', gap: 5, marginBottom: 12, flexWrap: 'wrap' }}>
            {['ALL', 'GOLES', '1X2'].map(c => (
              <button key={c} className={`filter-pill ${filter===c?'active':''}`} onClick={() => setFilter(c)}>{c}</button>
            ))}
          </div>
        </>
      )}

      {done && alerts.length === 0 && (
        <div className="info-y">Sin ineficiencias ≥ +{minEV}% en los deportes seleccionados. Baja el umbral o prueba con otros deportes.</div>
      )}

      {/* Alert cards */}
      {visible.map((a, i) => (
        <PickCard key={a.id} alert={a} bankroll={bankroll} onAddTracker={onAddTracker} delay={i * 0.04} />
      ))}

      {!done && !scanning && (
        <div className="empty">
          <div className="empty-icon">◈</div>
          <div className="empty-title">STANDBY</div>
          <div className="empty-desc">
            API key → Selecciona deportes → Play<br />
            Compara tu modelo vs Pinnacle en tiempo real<br />
            Sin CORS · Sin limitaciones
          </div>
        </div>
      )}
    </div>
  )
}

// ── MODEL PAGE ─────────────────────────────────────────────────────
function ModelPage({ sport, bankroll, onAddTracker }) {
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError]    = useState(null)

  // Football state
  const [fHome, setFHome]     = useState('')
  const [fAway, setFAway]     = useState('')
  const [fHxg,  setFHxg]      = useState('')
  const [fAxg,  setFAxg]      = useState('')
  const [fEuro, setFEuro]     = useState(false)
  const [fPinH, setFPinH]     = useState('')
  const [fPinX, setFPinX]     = useState('')
  const [fPinA, setFPinA]     = useState('')
  const [fCorn, setFCorn]     = useState('9.5')
  const [fCard, setFCard]     = useState('3.5')
  const [fMode, setFMode]     = useState('teams') // teams | manual

  // Tennis state
  const [tP1,   setTP1]       = useState('')
  const [tP2,   setTP2]       = useState('')
  const [tSurf, setTSurf]     = useState('clay')
  const [tPinH, setTPinH]     = useState('')
  const [tPinA, setTPinA]     = useState('')
  const [tBo5,  setTBo5]      = useState(false)

  // NHL state
  const [nHome, setNHome]     = useState('')
  const [nAway, setNAway]     = useState('')
  const [nPinH, setNPinH]     = useState('')
  const [nPinA, setNPinA]     = useState('')
  const [nLine, setNLine]     = useState('5.5')

  // NBA state
  const [bHome, setBHome]     = useState('')
  const [bAway, setBAway]     = useState('')
  const [bPinH, setBPinH]     = useState('')
  const [bPinA, setBPinA]     = useState('')
  const [bLine, setBLine]     = useState('220.5')

  const calc = async (payload) => {
    setLoading(true); setError(null); setResult(null)
    try {
      const res = await fetch('/api/model', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setResult({ sport: payload.sport, ...data })
    } catch (e) { setError(e.message) }
    setLoading(false)
  }

  const football_teams = Object.keys(XG_DB).sort()
  const tennis_players = Object.keys(ELO_BY_SURFACE.clay).sort()
  const nhl_teams = Object.keys(NHL_TEAMS).sort()
  const nba_teams = Object.keys(NBA_TEAMS).sort()

  const renderFootball = () => (
    <div>
      {/* Mode toggle */}
      <div style={{ display: 'flex', gap: 5, marginBottom: 12 }}>
        {[['teams','POR EQUIPO'],['manual','MANUAL xG']].map(([k,l]) => (
          <button key={k} className={`filter-pill ${fMode===k?'active':''}`} onClick={() => setFMode(k)} style={{ flex: 1, padding: '8px' }}>{l}</button>
        ))}
      </div>

      {fMode === 'teams' ? (
        <div className="g2" style={{ marginBottom: 8 }}>
          <div><Label>LOCAL</Label><Sel value={fHome} onChange={setFHome} options={football_teams} /></div>
          <div><Label>VISITANTE</Label><Sel value={fAway} onChange={setFAway} options={football_teams} /></div>
        </div>
      ) : (
        <div className="g2" style={{ marginBottom: 8 }}>
          <div><Label>xG LOCAL</Label><Inp value={fHxg} onChange={setFHxg} placeholder="1.50" /></div>
          <div><Label>xG VISITANTE</Label><Inp value={fAxg} onChange={setFAxg} placeholder="1.10" /></div>
        </div>
      )}

      {/* Post-Europa fade */}
      <div className="toggle-wrap" style={{ marginBottom: 8, border: `1px solid ${fEuro ? '#ff6b3540' : '#161616'}` }} onClick={() => setFEuro(!fEuro)}>
        <div className="toggle-box" style={{ borderColor: fEuro ? O : '#2a2a2a', background: fEuro ? O+'22' : 'transparent', color: O }}>
          {fEuro && '✓'}
        </div>
        <div>
          <div style={{ color: fEuro ? O : '#333', fontSize: 9, fontWeight: 700 }}>⚡ POST-EUROPA FADE</div>
          <div style={{ color: '#1a1a1a', fontSize: 7 }}>Local jugó Europa el jueves → reduce xG -13%</div>
        </div>
      </div>

      {/* Cuotas Pinnacle */}
      <div className="card" style={{ borderColor: `${Y}22` }}>
        <div className="card-title" style={{ color: Y }}>CUOTAS PINNACLE — PARA EV Y CLV EXACTOS</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 8 }}>
          {[['1 LOCAL',fPinH,setFPinH,'2.10'],['X EMPATE',fPinX,setFPinX,'3.40'],['2 VISIT.',fPinA,setFPinA,'3.20']].map(([l,v,s,ph]) => (
            <div key={l}><Label>{l}</Label><Inp value={v} onChange={s} placeholder={ph} /></div>
          ))}
        </div>
        <div className="g2">
          <div><Label>LÍNEA CÓRNERS</Label><Inp value={fCorn} onChange={setFCorn} placeholder="9.5" /></div>
          <div><Label>LÍNEA TARJETAS</Label><Inp value={fCard} onChange={setFCard} placeholder="3.5" /></div>
        </div>
      </div>

      <button className="btn-primary" onClick={() => calc({ sport: 'football', params: { home: fHome, away: fAway, hxgManual: fHxg, axgManual: fAxg, euroFade: fEuro, pinH: fPinH, pinX: fPinX, pinA: fPinA, cornLine: fCorn, cardLine: fCard, bankroll } })} disabled={loading} style={{ marginBottom: 14 }}>
        {loading ? <span style={{display:'flex',alignItems:'center',justifyContent:'center',gap:10}}><span className="spinner" />CALCULANDO...</span> : '▶ CALCULAR — TODOS LOS MERCADOS'}
      </button>
    </div>
  )

  const renderTennis = () => (
    <div>
      <div className="card" style={{ borderColor: `${Y}22` }}>
        <div className="card-title" style={{ color: Y }}>SUPERFICIE</div>
        <div style={{ display: 'flex', gap: 5, marginBottom: 8 }}>
          {[['clay','🟤 Arcilla'],['hard','🔵 Dura'],['grass','🟢 Hierba']].map(([k,l]) => (
            <button key={k} className={`filter-pill ${tSurf===k?'active':''}`} onClick={() => setTSurf(k)} style={{ flex: 1 }}>{l}</button>
          ))}
        </div>
        <div className="g2" style={{ marginBottom: 8 }}>
          <div><Label>JUGADOR 1</Label><Sel value={tP1} onChange={setTP1} options={tennis_players} /></div>
          <div><Label>JUGADOR 2</Label><Sel value={tP2} onChange={setTP2} options={tennis_players} /></div>
        </div>
        <div className="g2" style={{ marginBottom: 8 }}>
          <div><Label>CUOTA Pinnacle P1</Label><Inp value={tPinH} onChange={setTPinH} placeholder="1.75" /></div>
          <div><Label>CUOTA Pinnacle P2</Label><Inp value={tPinA} onChange={setTPinA} placeholder="2.20" /></div>
        </div>
        <div className="toggle-wrap" onClick={() => setTBo5(!tBo5)}>
          <div className="toggle-box" style={{ borderColor: tBo5 ? Y : '#2a2a2a', background: tBo5 ? Y+'22' : 'transparent', color: Y }}>{tBo5 && '✓'}</div>
          <span style={{ color: tBo5 ? Y : '#333', fontSize: 9 }}>Best of 5 (Grand Slam)</span>
        </div>
      </div>
      <button className="btn-primary" onClick={() => calc({ sport: 'tennis', params: { p1: tP1, p2: tP2, surface: tSurf, pinH: tPinH, pinA: tPinA, bo5: tBo5, bankroll } })} disabled={loading} style={{ marginBottom: 14 }}>
        {loading ? <span style={{display:'flex',alignItems:'center',justifyContent:'center',gap:10}}><span className="spinner" />CALCULANDO ELO...</span> : '▶ CALCULAR ELO SURFACE-ADJUSTED'}
      </button>
    </div>
  )

  const renderNHL = () => (
    <div>
      <div className="g2" style={{ marginBottom: 8 }}>
        <div><Label>LOCAL</Label><Sel value={nHome} onChange={setNHome} options={nhl_teams} /></div>
        <div><Label>VISITANTE</Label><Sel value={nAway} onChange={setNAway} options={nhl_teams} /></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 12 }}>
        {[['Pinnacle Local',nPinH,setNPinH,'2.10'],['Pinnacle Visit.',nPinA,setNPinA,'1.85'],['O/U Line',nLine,setNLine,'5.5']].map(([l,v,s,ph]) => (
          <div key={l}><Label>{l}</Label><Inp value={v} onChange={s} placeholder={ph} /></div>
        ))}
      </div>
      <button className="btn-primary" onClick={() => calc({ sport: 'nhl', params: { home: nHome, away: nAway, pinH: nPinH, pinA: nPinA, ouLine: nLine, bankroll } })} disabled={loading} style={{ marginBottom: 14 }}>
        {loading ? <span style={{display:'flex',alignItems:'center',justifyContent:'center',gap:10}}><span className="spinner" />CALCULANDO POISSON...</span> : '▶ CALCULAR POISSON NHL'}
      </button>
    </div>
  )

  const renderNBA = () => (
    <div>
      <div className="g2" style={{ marginBottom: 8 }}>
        <div><Label>LOCAL</Label><Sel value={bHome} onChange={setBHome} options={nba_teams} /></div>
        <div><Label>VISITANTE</Label><Sel value={bAway} onChange={setBAway} options={nba_teams} /></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 12 }}>
        {[['Pinnacle Local ML',bPinH,setBPinH,'1.91'],['Pinnacle Visit. ML',bPinA,setBPinA,'1.95'],['O/U',bLine,setBLine,'220.5']].map(([l,v,s,ph]) => (
          <div key={l}><Label>{l}</Label><Inp value={v} onChange={s} placeholder={ph} /></div>
        ))}
      </div>
      <button className="btn-primary" onClick={() => calc({ sport: 'nba', params: { home: bHome, away: bAway, pinH: bPinH, pinA: bPinA, ouLine: bLine, bankroll } })} disabled={loading} style={{ marginBottom: 14 }}>
        {loading ? <span style={{display:'flex',alignItems:'center',justifyContent:'center',gap:10}}><span className="spinner" />CALCULANDO PACE MODEL...</span> : '▶ CALCULAR PACE × EFFICIENCY'}
      </button>
    </div>
  )

  const renderResult = () => {
    if (!result) return null

    if (result.sport === 'football') {
      const { hxg, axg, probs, ht, over25, over35, btts, hCorn, aCorn, cornMean, cornP, expCards, cardP, vigInfo, picks, meta } = result
      return (
        <div>
          <div className="card" style={{ borderColor: `${P}33` }}>
            <div className="card-title" style={{ color: P }}>
              DIXON-COLES ρ=-0.13 · xG {hxg}/{axg}{meta.euroFade ? ' · POST-EUROPA FADE -13%' : ''}
            </div>
            {/* 1X2 */}
            <div className="g3" style={{ marginBottom: 10 }}>
              {[
                [meta.home||'Local', probs.hw, G, vigInfo?.noVig[0]],
                ['Empate',           probs.d,  Y, vigInfo?.noVig[1]],
                [meta.away||'Visit.',probs.aw, B, vigInfo?.noVig[2]],
              ].map(([k, p, c, nv]) => (
                <div key={k} className="sbox-lg">
                  <div className="sbox-lg-label">{k}</div>
                  <div className="sbox-lg-val" style={{ color: c }}>{p.toFixed(1)}%</div>
                  <div className="sbox-lg-sub">cuota {(100/p).toFixed(2)}</div>
                  {nv && (
                    <>
                      <div style={{ height: 1, background: '#111', margin: '6px 0' }} />
                      <div style={{ fontSize: 9, color: '#555' }}>Pinnacle: {(100/nv).toFixed(2)}</div>
                      <div style={{ fontSize: 8, color: '#1a1a1a' }}>No-vig: {nv.toFixed(1)}%</div>
                      <div style={{ fontSize: 10, fontWeight: 700, color: p >= nv ? G : R, marginTop: 2 }}>
                        {p >= nv ? '+' : ''}{(p - nv).toFixed(1)}pp
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>

            {/* Otros mercados */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 5, marginBottom: 10 }}>
              <SBox label="Over 2.5"   val={`${over25.toFixed(1)}%`} color={B} />
              <SBox label="Over 3.5"   val={`${over35.toFixed(1)}%`} color={P} />
              <SBox label="BTTS"        val={`${btts.toFixed(1)}%`}   color={Y} />
              <SBox label="HT Local"   val={`${ht.hw.toFixed(1)}%`}  color={G} sm />
            </div>

            {/* Córners */}
            {cornP && (
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 8, color: '#1a1a1a', marginBottom: 5 }}>CÓRNERS — Media esperada {cornMean} · Línea {fCorn}</div>
                <div className="g2">
                  <SBox label={`Over ${fCorn} córners`} val={`${cornP.over.toFixed(1)}%`} color={P} />
                  <SBox label={`Under ${fCorn} córners`} val={`${cornP.under.toFixed(1)}%`} color={B} />
                </div>
              </div>
            )}

            {/* Tarjetas */}
            {cardP && (
              <div>
                <div style={{ fontSize: 8, color: '#1a1a1a', marginBottom: 5 }}>TARJETAS — Media esperada {expCards} · Línea {fCard}</div>
                <div className="g2">
                  <SBox label={`Over ${fCard} tarjetas`}  val={`${cardP.over.toFixed(1)}%`}  color={O} />
                  <SBox label={`Under ${fCard} tarjetas`} val={`${cardP.under.toFixed(1)}%`} color="#555" />
                </div>
              </div>
            )}

            {vigInfo && <div style={{ marginTop: 8, fontSize: 8, color: '#2a2a2a' }}>Vig Pinnacle: <span style={{ color: Y }}>{vigInfo.vig.toFixed(2)}%</span></div>}
          </div>

          {/* Picks con EV positivo */}
          {picks.length > 0 && (
            <div>
              <div style={{ fontSize: 8, color: G, letterSpacing: 1, marginBottom: 8 }}>✓ VALUE BETS DETECTADAS</div>
              {picks.map(p => (
                <div key={p.label} style={{ background: '#0a0a0a', border: `1px solid ${evColor(p.ev)}33`, borderLeft: `3px solid ${evColor(p.ev)}`, borderRadius: 7, padding: '10px 12px', marginBottom: 8 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <div>
                      <div style={{ color: evColor(p.ev), fontSize: 8, fontWeight: 700 }}>EV {fmtEV(p.ev)} · CLV {fmtPct(p.clv)}</div>
                      <div style={{ color: '#ddd', fontSize: 13, fontWeight: 700 }}>{p.label}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ color: Y, fontSize: 15, fontWeight: 700 }}>{p.odds.toFixed(2)}</div>
                      <div style={{ color: '#1a1a1a', fontSize: 8 }}>¼ Kelly €{p.stake}</div>
                    </div>
                  </div>
                  <button className="btn-secondary" style={{ width: '100%' }} onClick={() => onAddTracker({ match: `${meta.home||'?'} vs ${meta.away||'?'}`, market: p.label, myOdds: p.odds, stake: p.stake })}>
                    + CLV TRACKER
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )
    }

    if (result.sport === 'tennis') {
      const { p1, p2, e1, e2, surface, p1win, p2win, setProbs, picks } = result
      return (
        <div>
          <div className="card" style={{ borderColor: `${Y}33` }}>
            <div className="card-title" style={{ color: Y }}>ELO {surface.toUpperCase()} · {p1} vs {p2}</div>
            <div className="g2" style={{ marginBottom: 10 }}>
              {[[p1, p1win, G, e1],[p2, p2win, B, e2]].map(([n,pw,c,e]) => (
                <div key={n} className="sbox-lg">
                  <div className="sbox-lg-label">{n}</div>
                  <div className="sbox-lg-val" style={{ color: c }}>{pw.toFixed(1)}%</div>
                  <div className="sbox-lg-sub">Elo {e} · {(100/pw).toFixed(2)}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 8, color: '#1a1a1a', marginBottom: 6 }}>DISTRIBUCIÓN DE SETS</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 5 }}>
              {Object.entries(setProbs).map(([k,v]) => (
                <SBox key={k} label={k} val={`${v}%`} color={+k[0] > +k[2] ? G : B} sm />
              ))}
            </div>
          </div>
          {picks.map(p => (
            <div key={p.label} style={{ background: '#0a0a0a', border: `1px solid ${evColor(p.ev)}33`, borderLeft: `3px solid ${evColor(p.ev)}`, borderRadius: 7, padding: '10px 12px', marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <div><div style={{ color: evColor(p.ev), fontSize: 8 }}>EV {fmtEV(p.ev)}</div><div style={{ color: '#ddd', fontSize: 13, fontWeight: 700 }}>{p.label}</div></div>
                <div style={{ color: Y, fontSize: 15, fontWeight: 700 }}>{p.odds.toFixed(2)}</div>
              </div>
              <button className="btn-secondary" style={{ width: '100%' }} onClick={() => onAddTracker({ match: `${p1} vs ${p2}`, market: p.label, myOdds: p.odds, stake: p.stake })}>+ TRACKER</button>
            </div>
          ))}
        </div>
      )
    }

    if (result.sport === 'nhl') {
      const { nhl, picks, home, away } = result
      return (
        <div>
          <div className="card" style={{ borderColor: `${B}33` }}>
            <div className="card-title" style={{ color: B }}>NHL POISSON · {home} vs {away}</div>
            <div className="g3" style={{ marginBottom: 10 }}>
              <SBox label={`${home} gana`}  val={`${nhl.hwFinal}%`} color={G} />
              <SBox label={`${away} gana`}  val={`${nhl.awFinal}%`} color={B} />
              <SBox label="OT esperado"       val={`${nhl.tieReg}%`}  color="#555" />
            </div>
            <div className="g3" style={{ marginBottom: 10 }}>
              <SBox label="Goles locales"  val={nhl.hg}          color={G} />
              <SBox label="Goles visit."   val={nhl.ag}          color={B} />
              <SBox label="Total esp."     val={nhl.total}       color={Y} />
            </div>
            <div className="g3">
              <SBox label="Over 5.5"  val={`${nhl.over55.toFixed(1)}%`} color={Y} />
              <SBox label="Over 6.5"  val={`${nhl.over65.toFixed(1)}%`} color={O} />
              <SBox label="Over 7.5"  val={`${nhl.over75.toFixed(1)}%`} color={R} />
            </div>
          </div>
          {picks.map(p => (
            <div key={p.label} style={{ background: '#0a0a0a', border: `1px solid ${evColor(p.ev)}33`, borderLeft: `3px solid ${evColor(p.ev)}`, borderRadius: 7, padding: '10px 12px', marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <div><div style={{ color: evColor(p.ev), fontSize: 8 }}>EV {fmtEV(p.ev)} · CLV {fmtPct(p.clv)}</div><div style={{ color: '#ddd', fontSize: 13, fontWeight: 700 }}>{p.label}</div></div>
                <div><div style={{ color: Y, fontSize: 15, fontWeight: 700 }}>{p.odds.toFixed(2)}</div><div style={{ color: '#1a1a1a', fontSize: 8 }}>€{p.stake} Kelly</div></div>
              </div>
              <button className="btn-secondary" style={{ width: '100%' }} onClick={() => onAddTracker({ match: `${home} vs ${away}`, market: p.label, myOdds: p.odds, stake: p.stake })}>+ TRACKER</button>
            </div>
          ))}
        </div>
      )
    }

    if (result.sport === 'nba') {
      const { nba, picks, home, away, ouLine } = result
      return (
        <div>
          <div className="card" style={{ borderColor: `${O}33` }}>
            <div className="card-title" style={{ color: O }}>NBA PACE MODEL · {home} vs {away}</div>
            <div className="g2" style={{ marginBottom: 10 }}>
              <div className="sbox-lg"><div className="sbox-lg-label">{home}</div><div className="sbox-lg-val" style={{ color: G }}>{nba.hPts}pts</div><div className="sbox-lg-sub">{nba.hwProb}% win</div></div>
              <div className="sbox-lg"><div className="sbox-lg-label">{away}</div><div className="sbox-lg-val" style={{ color: B }}>{nba.aPts}pts</div><div className="sbox-lg-sub">{nba.awProb}% win</div></div>
            </div>
            <div className="g3">
              <SBox label="Total previsto"  val={nba.total}  color={Y} />
              <SBox label="Spread"          val={`${nba.spread>0?'+':''}${nba.spread}`} color={P} />
              <SBox label="Pace"            val={nba.pace}   color="#555" />
            </div>
            {nba.total > ouLine && <div className="info-g" style={{ marginTop: 10 }}>⚡ Total previsto {nba.total} SUPERA la línea de {ouLine} → Over tiene valor potencial</div>}
          </div>
          {picks.map(p => (
            <div key={p.label} style={{ background: '#0a0a0a', border: `1px solid ${evColor(p.ev)}33`, borderLeft: `3px solid ${evColor(p.ev)}`, borderRadius: 7, padding: '10px 12px', marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <div><div style={{ color: evColor(p.ev), fontSize: 8 }}>EV {fmtEV(p.ev)}</div><div style={{ color: '#ddd', fontSize: 13, fontWeight: 700 }}>{p.label}</div></div>
                <div style={{ color: Y, fontSize: 15, fontWeight: 700 }}>{p.odds.toFixed(2)}</div>
              </div>
              <button className="btn-secondary" style={{ width: '100%' }} onClick={() => onAddTracker({ match: `${home} vs ${away}`, market: p.label, myOdds: p.odds, stake: p.stake })}>+ TRACKER</button>
            </div>
          ))}
        </div>
      )
    }
  }

  return (
    <div>
      {sport === 'football' && renderFootball()}
      {sport === 'tennis'   && renderTennis()}
      {sport === 'nhl'      && renderNHL()}
      {sport === 'nba'      && renderNBA()}
      {error && <div className="info-r">✗ {error}</div>}
      {renderResult()}
    </div>
  )
}

// ── TRACKER PAGE ───────────────────────────────────────────────────
function TrackerPage({ bets, setBets, preload, clearPreload }) {
  const [form, setForm] = useState({
    match: preload?.match || '', market: preload?.market || '',
    myOdds: preload?.myOdds?.toString() || '', closeOdds: '',
    stake: preload?.stake?.toString() || '', result: 'pending',
  })
  if (preload) clearPreload()

  const sf = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const addBet = () => {
    if (!form.match || !form.myOdds || !form.stake) return
    const clv = form.closeOdds ? clvCalc(+form.myOdds, +form.closeOdds) : null
    setBets(p => [...p, { id: Date.now(), ...form, myOdds: +form.myOdds, closeOdds: form.closeOdds ? +form.closeOdds : null, stake: +form.stake, clv, date: new Date().toLocaleDateString('es-ES') }])
    setForm({ match:'', market:'', myOdds:'', closeOdds:'', stake:'', result:'pending' })
  }

  const clvPrev = form.myOdds && form.closeOdds ? clvCalc(+form.myOdds, +form.closeOdds) : null

  return (
    <div>
      <div className="info-y">
        <strong style={{ color: Y }}>CLV = cuota tuya vs cierre Pinnacle sin margen.</strong><br />
        Positivo consistente tras 200+ bets = edge real demostrado matemáticamente. Independiente de resultados.
      </div>

      <div className="card">
        <div className="card-title" style={{ color: G }}>+ REGISTRAR APUESTA</div>
        <div className="g2" style={{ marginBottom: 8 }}>
          <div style={{ gridColumn: '1/-1' }}><Label>PARTIDO / EVENTO</Label><Inp value={form.match} onChange={v => sf('match',v)} type="text" placeholder="Tottenham vs Leeds" /></div>
          <div style={{ gridColumn: '1/-1' }}><Label>MERCADO</Label><Inp value={form.market} onChange={v => sf('market',v)} type="text" placeholder="BTTS Sí" /></div>
          <div><Label>MI CUOTA</Label><Inp value={form.myOdds} onChange={v => sf('myOdds',v)} placeholder="1.70" /></div>
          <div><Label>STAKE €</Label><Inp value={form.stake} onChange={v => sf('stake',v)} placeholder="50" /></div>
          <div><Label>CIERRE PINNACLE</Label><Inp value={form.closeOdds} onChange={v => sf('closeOdds',v)} placeholder="Al kickoff" /></div>
          <div>
            <Label>RESULTADO</Label>
            <select className="inp" value={form.result} onChange={e => sf('result', e.target.value)}>
              <option value="pending">⏳ Pendiente</option>
              <option value="won">✓ Ganada</option>
              <option value="lost">✗ Perdida</option>
              <option value="void">○ Anulada</option>
            </select>
          </div>
        </div>

        {clvPrev && (
          <div style={{ background: '#080808', borderRadius: 5, padding: '7px 10px', marginBottom: 8, display: 'flex', gap: 12, fontSize: 9, flexWrap: 'wrap' }}>
            <span style={{ color: '#1a1a1a' }}>Mi imp: <strong style={{ color: B }}>{clvPrev.takenImpl.toFixed(1)}%</strong></span>
            <span style={{ color: '#1a1a1a' }}>Pin no-vig: <strong style={{ color: P }}>{clvPrev.closingNoVig.toFixed(1)}%</strong></span>
            <span style={{ color: '#1a1a1a' }}>CLV: <strong style={{ color: -clvPrev.clv >= 0 ? G : R }}>{fmtPct(-clvPrev.clv)} {-clvPrev.clv >= 0 ? '✓ EDGE' : '✗ SIN EDGE'}</strong></span>
          </div>
        )}

        <button className="btn-primary" onClick={addBet}>AÑADIR AL TRACKER</button>
      </div>

      {bets.length === 0 ? (
        <div className="empty"><div className="empty-icon">📊</div><div className="empty-title">SIN APUESTAS</div><div className="empty-desc">Registra tus apuestas aquí<br />Añade el cierre de Pinnacle al kickoff</div></div>
      ) : bets.map(bet => {
        const pB = bet.result === 'won' ? bet.stake * (bet.myOdds - 1) : bet.result === 'lost' ? -bet.stake : 0
        const cv = bet.clv ? +(-bet.clv.clv).toFixed(2) : null
        const sc = bet.result === 'won' ? G : bet.result === 'lost' ? R : bet.result === 'pending' ? Y : '#444'
        return (
          <div key={bet.id} style={{ background: '#0a0a0a', border: '1px solid #161616', borderLeft: `3px solid ${sc}`, borderRadius: 8, padding: '11px 13px', marginBottom: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 7 }}>
              <div>
                <div style={{ color: '#ddd', fontSize: 11, fontWeight: 700 }}>{bet.match}</div>
                <div style={{ color: '#444', fontSize: 9, marginTop: 2 }}>{bet.market} · {bet.date}</div>
              </div>
              <div style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
                <div className="rbtn-row">
                  {['pending','won','lost','void'].map(r => (
                    <button key={r} className={`rbtn ${bet.result===r?'active':''}`} style={{ color: r==='won'?G:r==='lost'?R:r==='void'?'#444':Y }} onClick={() => setBets(p => p.map(b => b.id===bet.id?{...b,result:r}:b))}>
                      {r==='pending'?'⏳':r==='won'?'W':r==='lost'?'L':'V'}
                    </button>
                  ))}
                </div>
                <button onClick={() => setBets(p => p.filter(b => b.id!==bet.id))} className="btn-ghost" style={{ marginLeft: 2 }}>✕</button>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 4 }}>
              {[['Cuota',bet.myOdds.toFixed(2),'#bbb'],['€',bet.stake,'#444'],['P&L',bet.result==='pending'?'—':fmtPnl(pB),pB>=0&&bet.result!=='pending'?G:bet.result==='lost'?R:'#444'],['Cierre',bet.closeOdds?bet.closeOdds.toFixed(2):'—',P],['CLV',cv!==null?fmtPct(cv):'—',cv!==null?(cv>=0?G:R):'#444']].map(([k,v,c]) => (
                <div key={k} style={{ background: '#080808', borderRadius: 4, padding: '5px', textAlign: 'center' }}>
                  <div style={{ color: '#1a1a1a', fontSize: 7, marginBottom: 2 }}>{k}</div>
                  <div style={{ color: c, fontSize: 10, fontWeight: 700 }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── PORTFOLIO PAGE ─────────────────────────────────────────────────
function PortfolioPage({ bets }) {
  const settled = bets.filter(b => b.result !== 'pending')
  if (!settled.length) return <div className="empty"><div className="empty-icon">💼</div><div className="empty-title">SIN DATOS AÚN</div><div className="empty-desc">Registra apuestas en el Tracker</div></div>

  const won  = bets.filter(b => b.result === 'won')
  const lost = bets.filter(b => b.result === 'lost')
  const staked = settled.reduce((s,b) => s+b.stake, 0)
  const pnl  = won.reduce((s,b) => s+b.stake*(b.myOdds-1), 0) - lost.reduce((s,b) => s+b.stake, 0)
  const roi  = staked > 0 ? (pnl/staked)*100 : 0
  const cvB  = bets.filter(b => b.clv)
  const avgCLV = cvB.length > 0 ? cvB.reduce((s,b) => s+(-b.clv.clv), 0)/cvB.length : null
  const wr   = settled.length > 0 ? (won.length/settled.length*100) : 0

  return (
    <div>
      <div className="g2" style={{ marginBottom: 10 }}>
        {[
          ['P&L TOTAL', fmtPnl(pnl),                     pnl>=0?G:R],
          ['ROI',       `${roi>=0?'+':''}${roi.toFixed(1)}%`, roi>=0?G:R],
          ['APUESTAS',  `${settled.length} (${won.length}W/${lost.length}L)`, B],
          ['WIN RATE',  `${wr.toFixed(0)}%`,               wr>=50?G:R],
          ['CLV PROM',  avgCLV!==null?fmtPct(avgCLV):'—', avgCLV!==null?(avgCLV>=0?G:R):'#444'],
          ['STAKED',    `€${staked.toFixed(0)}`,            '#555'],
        ].map(([k,v,c]) => (
          <div key={k} className="card" style={{ textAlign: 'center', padding: '12px 8px' }}>
            <div style={{ color: '#1a1a1a', fontSize: 7, letterSpacing: 1, marginBottom: 5 }}>{k}</div>
            <div style={{ color: c, fontSize: 20, fontWeight: 700 }}>{v}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ borderColor: `${P}22` }}>
        <div className="card-title" style={{ color: P }}>DIAGNÓSTICO CLV vs PINNACLE</div>
        {cvB.length === 0 ? (
          <div style={{ color: '#2a2a2a', fontSize: 9 }}>Añade cuotas de cierre de Pinnacle en el Tracker para validar tu edge.</div>
        ) : (
          <>
            <div style={{ fontSize: 9, marginBottom: 8 }}>
              <strong style={{ color: avgCLV && avgCLV > 0 ? G : R }}>
                {avgCLV && avgCLV > 0 ? '✓ CLV POSITIVO — Edge real demostrado sobre Pinnacle' : '⚠ CLV NEGATIVO — Tus precios están por debajo del mercado sharp'}
              </strong>
            </div>
            <div className="g3" style={{ marginBottom: 8 }}>
              <SBox label="CLV+ bets"   val={`${cvB.filter(b=>(-b.clv.clv)>0).length}/${cvB.length}`} color={G} />
              <SBox label="CLV medio"   val={avgCLV!==null?fmtPct(avgCLV):'—'} color={avgCLV&&avgCLV>0?G:R} />
              <SBox label="Muestra req" val="200+" color="#555" />
            </div>
            <div style={{ fontSize: 8, color: '#1a1a1a', lineHeight: 1.8 }}>
              CLV positivo consistente = sistema ganador a largo plazo, independiente de rachas de resultados.<br />
              Necesitas 200+ apuestas para significancia estadística robusta.
            </div>
          </>
        )}
      </div>

      <div className="card">
        <div className="card-title">HISTORIAL COMPLETO ({bets.length})</div>
        {bets.slice().reverse().map(bet => {
          const pB = bet.result==='won' ? bet.stake*(bet.myOdds-1) : bet.result==='lost' ? -bet.stake : 0
          const cv = bet.clv ? +(-bet.clv.clv).toFixed(2) : null
          return (
            <div key={bet.id} style={{ display:'grid', gridTemplateColumns:'2fr 1fr 1fr 1fr', gap:'4px 8px', padding:'5px 0', borderBottom:'1px solid #0a0a0a', alignItems:'center' }}>
              <div>
                <div style={{ color:'#777', fontSize:9, fontWeight:700, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{bet.match}</div>
                <div style={{ color:'var(--dimmer)', fontSize:7 }}>{bet.market}</div>
              </div>
              <div style={{ color:'#bbb', fontSize:9, textAlign:'center' }}>{bet.myOdds.toFixed(2)}</div>
              <div style={{ color:pB>=0&&bet.result!=='pending'?G:bet.result==='lost'?R:'#444', fontSize:9, textAlign:'center', fontWeight:700 }}>{bet.result==='pending'?'⏳':fmtPnl(pB)}</div>
              <div style={{ color:cv!==null?(cv>=0?G:R):'#444', fontSize:9, textAlign:'center' }}>{cv!==null?fmtPct(cv):'—'}</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── MAIN APP ───────────────────────────────────────────────────────
export default function App() {
  const [sport,   setSport]   = useState('football')
  const [page,    setPage]    = useState('scanner')
  const [bankroll,setBankroll]= useState(1000)
  const [bets,    setBets]    = useState([])
  const [preload, setPreload] = useState(null)

  // Persist bets
  useEffect(() => {
    if (typeof window === 'undefined') return
    const saved = localStorage.getItem('se_bets_v2')
    if (saved) setBets(JSON.parse(saved))
  }, [])

  useEffect(() => {
    if (typeof window !== 'undefined' && bets.length >= 0) {
      localStorage.setItem('se_bets_v2', JSON.stringify(bets))
    }
  }, [bets])

  const onAddTracker = useCallback(data => { setPreload(data); setPage('tracker') }, [])

  const settled = bets.filter(b => b.result !== 'pending')
  const won  = bets.filter(b => b.result === 'won')
  const lost = bets.filter(b => b.result === 'lost')
  const pnl  = won.reduce((s,b) => s+b.stake*(b.myOdds-1), 0) - lost.reduce((s,b) => s+b.stake, 0)
  const roi  = settled.reduce((s,b)=>s+b.stake,0) > 0 ? (pnl/settled.reduce((s,b)=>s+b.stake,0))*100 : 0
  const cvB  = bets.filter(b => b.clv)
  const avgCLV = cvB.length > 0 ? cvB.reduce((s,b) => s+(-b.clv.clv),0)/cvB.length : null

  return (
    <>
      <Head>
        <title>Sharp Edge Pro · Value Betting System</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
      </Head>

      <div style={{ display:'flex', flexDirection:'column', height:'100vh', overflow:'hidden' }}>

        {/* HEADER */}
        <div style={{ background:'#080808', borderBottom:'1px solid #161616', padding:'10px 14px', flexShrink:0 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <div>
              <div style={{ color:G, fontSize:15, fontWeight:700, letterSpacing:3, animation:'glow 3s ease infinite' }}>◈ SHARP EDGE PRO</div>
              <div style={{ display:'flex', gap:8, marginTop:3, flexWrap:'wrap' }}>
                {[['DC','⚽ Fútbol',G],['Elo','🎾 Tenis',Y],['Poisson','🏒 NHL',B],['Pace','🏀 NBA',O]].map(([k,v,c]) => (
                  <span key={k} style={{ fontSize:7, color:'#1a1a1a' }}>{k}: <span style={{ color:c, fontWeight:700 }}>{v}</span></span>
                ))}
              </div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:5 }}>
              <span style={{ color:'#1a1a1a', fontSize:7 }}>BANK €</span>
              <input
                value={bankroll}
                onChange={e => setBankroll(+e.target.value||1000)}
                type="number"
                style={{ background:'#080808', border:'1px solid #161616', borderRadius:4, color:Y, fontWeight:700, fontSize:13, fontFamily:'monospace', padding:'4px 7px', width:68, textAlign:'right' }}
              />
            </div>
          </div>

          {settled.length > 0 && (
            <div style={{ display:'flex', gap:12, marginTop:7, paddingTop:7, borderTop:'1px solid #111', fontSize:9 }}>
              <span style={{ color:'#1a1a1a' }}>P&L: <strong style={{ color:pnl>=0?G:R }}>{fmtPnl(pnl)}</strong></span>
              <span style={{ color:'#1a1a1a' }}>ROI: <strong style={{ color:roi>=0?G:R }}>{roi>=0?'+':''}{roi.toFixed(1)}%</strong></span>
              <span style={{ color:'#1a1a1a' }}>Bets: <strong style={{ color:'#555' }}>{settled.length}({won.length}W/{lost.length}L)</strong></span>
              {avgCLV!==null && <span style={{ color:'#1a1a1a' }}>CLV: <strong style={{ color:avgCLV>=0?G:R }}>{fmtPct(avgCLV)}</strong></span>}
            </div>
          )}
        </div>

        {/* SPORT TABS */}
        <div style={{ display:'flex', background:'#070707', borderBottom:'1px solid #161616', flexShrink:0, overflowX:'auto' }}>
          {SPORT_TABS.map(s => (
            <button
              key={s.key}
              onClick={() => setSport(s.key)}
              style={{
                flexShrink:0, padding:'9px 16px', fontSize:9, letterSpacing:1.5, fontFamily:'monospace',
                background: sport===s.key ? `${s.color}0a` : 'transparent',
                borderBottom: `2px solid ${sport===s.key ? s.color : 'transparent'}`,
                color: sport===s.key ? s.color : '#2a2a2a',
                border: 'none', borderRadius: 0, whiteSpace: 'nowrap', transition: 'all .15s',
              }}
            >
              {s.label}
            </button>
          ))}
        </div>

        {/* CONTENT */}
        <div style={{ flex:1, overflowY:'auto', padding:'12px 14px', maxWidth:660, margin:'0 auto', width:'100%' }}>
          {page === 'scanner'   && <ScannerPage   bankroll={bankroll} onAddTracker={onAddTracker} />}
          {page === 'model'     && <ModelPage     sport={sport} bankroll={bankroll} onAddTracker={onAddTracker} />}
          {page === 'tracker'   && <TrackerPage   bets={bets} setBets={setBets} preload={preload} clearPreload={() => setPreload(null)} />}
          {page === 'portfolio' && <PortfolioPage bets={bets} />}

          <div style={{ padding:'6px 10px', background:'#090909', border:'1px solid #0a0a0a', borderRadius:5, color:'#111', fontSize:7, lineHeight:1.8, marginTop:12 }}>
            Dixon-Coles (1997) · Elo surface-adjusted · Poisson NHL · Pace×Efficiency NBA · xG FootyStats/Opta · CLV vs Pinnacle no-vig · Shin method · ¼ Kelly.<br />
            No asesoramiento financiero. Las apuestas implican riesgo de pérdida. +18. FEJAR 900 81 08 25.
          </div>
        </div>

        {/* BOTTOM TABS */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', background:'#070707', borderTop:'1px solid #161616', flexShrink:0 }}>
          {PAGE_TABS.map(t => (
            <button
              key={t.key}
              onClick={() => setPage(t.key)}
              style={{
                padding:'10px 4px', fontSize:8, letterSpacing:1, fontFamily:'monospace',
                background: page===t.key ? `${G}08` : 'transparent',
                borderTop: `2px solid ${page===t.key ? G : 'transparent'}`,
                color: page===t.key ? G : '#2a2a2a',
                border: 'none', borderRadius: 0, transition: 'all .15s',
              }}
            >
              {t.icon} {t.label.split(' ')[1]}
            </button>
          ))}
        </div>
      </div>
    </>
  )
}
