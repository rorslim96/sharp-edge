// pages/api/scan.js
// Server-side API route — sin CORS, llama a The Odds API directamente

import { dixonColes, overGoals, bttsProb, evCalc, removeVig, kellyFraction, toImplied, poissonMarket } from '../../lib/models'
import { XG_DB, getMatchXG, NHL_TEAMS, NHL_LEAGUE_AVG, NHL_HOME_ADV, NBA_TEAMS, NBA_LEAGUE_ORTG, NBA_HOME_ADV, ELO_BY_SURFACE } from '../../lib/data'
import { nhlPoisson, nbaPaceModel, eloWinProb } from '../../lib/models'

const MARKETS = {
  soccer:  'h2h,totals,spreads',
  hockey:  'h2h,totals',
  basketball: 'h2h,totals,spreads',
  tennis:  'h2h',
}

async function fetchOdds(apiKey, sportKey, market = 'h2h,totals') {
  const url = new URL(`https://api.the-odds-api.com/v4/sports/${sportKey}/odds/`)
  url.searchParams.set('apiKey', apiKey)
  url.searchParams.set('regions', 'eu,uk')
  url.searchParams.set('markets', market)
  url.searchParams.set('oddsFormat', 'decimal')
  url.searchParams.set('bookmakers', 'pinnacle,bet365,betway,unibet,williamhill')
  url.searchParams.set('dateFormat', 'iso')

  const res = await fetch(url.toString(), {
    next: { revalidate: 300 }, // cache 5 min
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.message || `HTTP ${res.status}`)
  }

  const remaining = res.headers.get('x-requests-remaining')
  const data = await res.json()
  return { data, remaining }
}

function analyzeFootball(event, minEV, bankroll) {
  const bms = event.bookmakers || []
  const pin = bms.find(b => b.key === 'pinnacle')
  const b365 = bms.find(b => b.key === 'bet365')
  const ref = pin || b365
  if (!ref) return []

  const results = []
  const xg = getMatchXG(event.home_team, event.away_team)

  const h2h = ref.markets?.find(m => m.key === 'h2h')
  if (h2h) {
    const oH = h2h.outcomes.find(o => o.name === event.home_team)?.price
    const oD = h2h.outcomes.find(o => o.name === 'Draw')?.price
    const oA = h2h.outcomes.find(o => o.name === event.away_team)?.price

    if (oH && oD && oA) {
      const vigInfo = removeVig([oH, oD, oA])
      const probs = xg
        ? dixonColes(xg.hxg, xg.axg)
        : { hw: vigInfo.noVig[0], d: vigInfo.noVig[1], aw: vigInfo.noVig[2] }

      const candidates = [
        { market: `1 — ${event.home_team}`, dec: oH, prob: probs.hw, nvProb: vigInfo.noVig[0] },
        { market: 'X — Empate',            dec: oD, prob: probs.d,  nvProb: vigInfo.noVig[1] },
        { market: `2 — ${event.away_team}`, dec: oA, prob: probs.aw, nvProb: vigInfo.noVig[2] },
      ]

      // Over/Under derivados
      if (xg) {
        ;[2.5, 3.5].forEach(line => {
          const over = overGoals(xg.hxg, xg.axg, line)
          const under = 100 - over
          candidates.push(
            { market: `Over ${line}`,  dec: 0, prob: over,  nvProb: over,  derived: true, line },
            { market: `Under ${line}`, dec: 0, prob: under, nvProb: under, derived: true, line }
          )
        })

        // BTTS
        const btts = bttsProb(xg.hxg, xg.axg)
        candidates.push({ market: 'BTTS Sí', dec: 0, prob: btts, nvProb: btts, derived: true })
        candidates.push({ market: 'BTTS No', dec: 0, prob: 100-btts, nvProb: 100-btts, derived: true })
      }

      // Enriquecer con cuotas de totales de Pinnacle
      const totals = ref.markets?.find(m => m.key === 'totals')
      if (totals && xg) {
        totals.outcomes.forEach(o => {
          if (!o.point) return
          const over = overGoals(xg.hxg, xg.axg, o.point)
          const prob = o.name === 'Over' ? over : 100 - over
          const ev = evCalc(prob, o.price)
          if (ev >= minEV) {
            results.push(buildAlert({
              market: `${o.name} ${o.point} Goles`,
              dec: o.price, prob,
              nvProb: toImplied(o.price) * (1 - vigInfo.vig/100),
              ev, event, ref, xg, bankroll,
            }))
          }
        })
      }

      candidates.filter(c => !c.derived && c.dec > 1).forEach(c => {
        const ev = evCalc(c.prob, c.dec)
        if (ev >= minEV) {
          results.push(buildAlert({ ...c, ev, event, ref, xg, bankroll }))
        }
      })
    }
  }

  return results
}

function buildAlert({ market, dec, prob, nvProb, ev, event, ref, xg, bankroll }) {
  const imp = toImplied(dec)
  return {
    id:       `${event.id}-${market}`,
    match:    `${event.home_team} vs ${event.away_team}`,
    time:     new Date(event.commence_time).toLocaleTimeString('es-ES', { hour:'2-digit', minute:'2-digit' }),
    date:     new Date(event.commence_time).toLocaleDateString('es-ES', { day:'numeric', month:'short' }),
    ts:       event.commence_time,
    market,
    dec,
    prob:     +prob.toFixed(1),
    imp,
    ev:       +ev.toFixed(2),
    clvDC:    +(prob - nvProb).toFixed(1),
    nvProb:   +nvProb.toFixed(1),
    stake:    kellyFraction(prob, dec, bankroll),
    conf:     ev > 15 ? 'ALTO' : ev > 8 ? 'MEDIO' : 'BAJO',
    src:      ref.key,
    hxg:      xg?.hxg,
    axg:      xg?.axg,
    hCorn:    xg?.hCorn,
    aCorn:    xg?.aCorn,
    expCards: xg?.expectedCards,
  }
}

function analyzeNHL(event, minEV, bankroll) {
  const bms = event.bookmakers || []
  const pin = bms.find(b => b.key === 'pinnacle') || bms[0]
  if (!pin) return []

  const h2h = pin.markets?.find(m => m.key === 'h2h')
  const totals = pin.markets?.find(m => m.key === 'totals')
  const results = []

  const hTeam = NHL_TEAMS[event.home_team]
  const aTeam = NHL_TEAMS[event.away_team]

  if (h2h && hTeam && aTeam) {
    const oH = h2h.outcomes.find(o => o.name === event.home_team)?.price
    const oA = h2h.outcomes.find(o => o.name === event.away_team)?.price
    if (!oH || !oA) return []

    const nhl = nhlPoisson(hTeam.gf, hTeam.ga, aTeam.gf, aTeam.ga, NHL_LEAGUE_AVG, NHL_HOME_ADV)

    ;[
      { market: `1 — ${event.home_team}`, dec: oH, prob: nhl.hwFinal },
      { market: `2 — ${event.away_team}`, dec: oA, prob: nhl.awFinal },
    ].forEach(c => {
      const ev = evCalc(c.prob, c.dec)
      const nv = toImplied(c.dec) * 0.955
      if (ev >= minEV) {
        results.push({ ...buildAlert({ ...c, ev, event, ref: pin, xg: null, bankroll, nvProb: nv }), nhl })
      }
    })

    if (totals) {
      totals.outcomes.forEach(o => {
        if (!o.point) return
        const over = o.name === 'Over' ? nhl.over65 : 100 - nhl.over65
        const ev = evCalc(over, o.price)
        const nv = toImplied(o.price) * 0.955
        if (ev >= minEV) {
          results.push({ ...buildAlert({ market: `${o.name} ${o.point}`, dec: o.price, prob: over, ev, event, ref: pin, xg: null, bankroll, nvProb: nv }), nhl })
        }
      })
    }
  }

  return results
}

function analyzeNBA(event, minEV, bankroll) {
  const bms = event.bookmakers || []
  const pin = bms.find(b => b.key === 'pinnacle') || bms[0]
  if (!pin) return []

  const h2h = pin.markets?.find(m => m.key === 'h2h')
  if (!h2h) return []

  const hTeam = NBA_TEAMS[event.home_team]
  const aTeam = NBA_TEAMS[event.away_team]
  if (!hTeam || !aTeam) return []

  const nba = nbaPaceModel(
    hTeam.off, hTeam.def, hTeam.pace,
    aTeam.off, aTeam.def, aTeam.pace,
    NBA_LEAGUE_ORTG, NBA_HOME_ADV
  )

  const results = []
  const oH = h2h.outcomes.find(o => o.name === event.home_team)?.price
  const oA = h2h.outcomes.find(o => o.name === event.away_team)?.price
  if (!oH || !oA) return []

  ;[
    { market: `1 — ${event.home_team}`, dec: oH, prob: nba.hwProb },
    { market: `2 — ${event.away_team}`, dec: oA, prob: nba.awProb },
  ].forEach(c => {
    const ev = evCalc(c.prob, c.dec)
    const nv = toImplied(c.dec) * 0.96
    if (ev >= minEV) {
      results.push({ ...buildAlert({ ...c, ev, event, ref: pin, xg: null, bankroll, nvProb: nv }), nba })
    }
  })

  const totals = pin.markets?.find(m => m.key === 'totals')
  if (totals) {
    totals.outcomes.forEach(o => {
      if (!o.point) return
      const over = nba.total > o.point ? 62 : 38
      const ev = evCalc(over, o.price)
      const nv = toImplied(o.price) * 0.96
      if (ev >= minEV) {
        results.push({ ...buildAlert({ market: `${o.name} ${o.point}`, dec: o.price, prob: over, ev, event, ref: pin, xg: null, bankroll, nvProb: nv }), nba })
      }
    })
  }

  return results
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const { apiKey, sports, minEV = 5, bankroll = 1000 } = req.body

  if (!apiKey) return res.status(400).json({ error: 'API key requerida' })
  if (!sports?.length) return res.status(400).json({ error: 'Selecciona al menos un deporte' })

  const allAlerts = []
  const log = []
  let remaining = '?'

  for (const { key: sportKey, type } of sports) {
    try {
      log.push(`📡 Consultando ${sportKey}...`)
      const { data: events, remaining: rem } = await fetchOdds(apiKey, sportKey)
      remaining = rem
      log.push(`   ${events.length} eventos encontrados`)

      for (const event of events) {
        let alerts = []
        if (type === 'soccer')     alerts = analyzeFootball(event, minEV, bankroll)
        else if (type === 'hockey') alerts = analyzeNHL(event, minEV, bankroll)
        else if (type === 'basketball') alerts = analyzeNBA(event, minEV, bankroll)

        if (alerts.length) {
          log.push(`   🚨 ${event.home_team} vs ${event.away_team}: ${alerts.length} value bet(s)`)
          allAlerts.push(...alerts)
        }
      }
    } catch (e) {
      log.push(`   ✗ Error en ${sportKey}: ${e.message}`)
    }
  }

  allAlerts.sort((a, b) => b.ev - a.ev)

  res.status(200).json({
    alerts:    allAlerts,
    total:     allAlerts.length,
    log,
    remaining,
    timestamp: new Date().toISOString(),
  })
}
