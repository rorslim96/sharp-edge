// pages/api/model.js
import { dixonColes, overGoals, bttsProb, halfTimeProb, evCalc, kellyFraction, removeVig, toImplied, poissonMarket, nhlPoisson, nbaPaceModel, eloWinProb, tennisSetProbs } from '../../lib/models'
import { getMatchXG, NHL_TEAMS, NHL_LEAGUE_AVG, NHL_HOME_ADV, NBA_TEAMS, NBA_LEAGUE_ORTG, NBA_HOME_ADV, ELO_BY_SURFACE } from '../../lib/data'

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const { sport, params } = req.body

  try {
    if (sport === 'football') {
      const { home, away, hxgManual, axgManual, euroFade, pinH, pinX, pinA, cornLine, cardLine, bankroll = 1000 } = params

      let hxg, axg, hCorn, aCorn, expCards
      const xg = home && away ? getMatchXG(home, away) : null

      if (xg) {
        hxg = xg.hxg; axg = xg.axg
        hCorn = xg.hCorn; aCorn = xg.aCorn; expCards = xg.expectedCards
      } else if (hxgManual && axgManual) {
        hxg = +hxgManual; axg = +axgManual
      } else {
        return res.status(400).json({ error: 'Selecciona equipos o introduce xG manual' })
      }

      // Post-Europa Fade: -13% xG local
      if (euroFade) hxg = +(hxg * 0.87).toFixed(2)

      const probs    = dixonColes(hxg, axg)
      const ht       = halfTimeProb(hxg, axg)
      const over25   = overGoals(hxg, axg, 2.5)
      const over35   = overGoals(hxg, axg, 3.5)
      const btts     = bttsProb(hxg, axg)
      const cornMean = (hCorn || 5.5) + (aCorn || 4.5)
      const cornP    = cornLine ? poissonMarket(cornMean, +cornLine) : null
      const cardP    = cardLine ? poissonMarket(expCards || 3.5, +cardLine) : null

      // Si hay cuotas Pinnacle
      let vigInfo = null
      let picks = []
      if (pinH && pinX && pinA) {
        vigInfo = removeVig([+pinH, +pinX, +pinA])
        const odds = [+pinH, +pinX, +pinA]
        const modelProbs = [probs.hw, probs.d, probs.aw]
        const labels = [`1 — ${home || 'Local'}`, 'X — Empate', `2 — ${away || 'Visitante'}`]

        picks = labels.map((label, i) => {
          const ev = evCalc(modelProbs[i], odds[i])
          const stake = kellyFraction(modelProbs[i], odds[i], bankroll)
          const clv = +(modelProbs[i] - vigInfo.noVig[i]).toFixed(1)
          return { label, odds: odds[i], prob: +modelProbs[i].toFixed(1), ev: +ev.toFixed(2), stake, clv, nvProb: vigInfo.noVig[i] }
        }).filter(p => p.ev > 0)
      }

      return res.status(200).json({
        hxg, axg, probs, ht, over25, over35, btts,
        hCorn, aCorn, cornMean: +cornMean.toFixed(1), cornP,
        expCards, cardP,
        vigInfo, picks,
        meta: { home, away, euroFade }
      })
    }

    if (sport === 'nhl') {
      const { home, away, pinH, pinA, ouLine = 5.5, bankroll = 1000 } = params
      const hT = NHL_TEAMS[home], aT = NHL_TEAMS[away]
      if (!hT || !aT) return res.status(400).json({ error: 'Equipos no encontrados' })

      const nhl = nhlPoisson(hT.gf, hT.ga, aT.gf, aT.ga, NHL_LEAGUE_AVG, NHL_HOME_ADV)
      const picks = []

      if (pinH) {
        const ev = evCalc(nhl.hwFinal, +pinH)
        const nv = toImplied(+pinH) * 0.955
        if (ev > 0) picks.push({ label: `Local gana — ${home}`, odds: +pinH, prob: +nhl.hwFinal.toFixed(1), ev: +ev.toFixed(2), stake: kellyFraction(nhl.hwFinal, +pinH, bankroll), clv: +(nhl.hwFinal - nv).toFixed(1) })
      }
      if (pinA) {
        const ev = evCalc(nhl.awFinal, +pinA)
        const nv = toImplied(+pinA) * 0.955
        if (ev > 0) picks.push({ label: `Visitante gana — ${away}`, odds: +pinA, prob: +nhl.awFinal.toFixed(1), ev: +ev.toFixed(2), stake: kellyFraction(nhl.awFinal, +pinA, bankroll), clv: +(nhl.awFinal - nv).toFixed(1) })
      }

      return res.status(200).json({ nhl, picks, home, away })
    }

    if (sport === 'nba') {
      const { home, away, pinH, pinA, ouLine = 220.5, bankroll = 1000 } = params
      const hT = NBA_TEAMS[home], aT = NBA_TEAMS[away]
      if (!hT || !aT) return res.status(400).json({ error: 'Equipos no encontrados' })

      const nba = nbaPaceModel(hT.off, hT.def, hT.pace, aT.off, aT.def, aT.pace, NBA_LEAGUE_ORTG, NBA_HOME_ADV)
      const picks = []

      if (pinH) {
        const ev = evCalc(nba.hwProb, +pinH)
        if (ev > 0) picks.push({ label: `Local — ${home}`, odds: +pinH, prob: nba.hwProb, ev: +ev.toFixed(2), stake: kellyFraction(nba.hwProb, +pinH, bankroll) })
      }
      if (pinA) {
        const ev = evCalc(nba.awProb, +pinA)
        if (ev > 0) picks.push({ label: `Visitante — ${away}`, odds: +pinA, prob: nba.awProb, ev: +ev.toFixed(2), stake: kellyFraction(nba.awProb, +pinA, bankroll) })
      }

      return res.status(200).json({ nba, picks, home, away, ouLine: +ouLine })
    }

    if (sport === 'tennis') {
      const { p1, p2, surface = 'clay', pinH, pinA, bo5 = false, bankroll = 1000 } = params
      const eloDb = ELO_BY_SURFACE[surface] || ELO_BY_SURFACE.clay
      const e1 = eloDb[p1] || 1900
      const e2 = eloDb[p2] || 1900
      const p1win = eloWinProb(e1, e2, surface)
      const p2win = +(100 - p1win).toFixed(1)
      const setProbs = tennisSetProbs(p1win, bo5)
      const picks = []

      if (pinH) {
        const ev = evCalc(p1win, +pinH)
        if (ev > 0) picks.push({ label: p1, odds: +pinH, prob: +p1win.toFixed(1), ev: +ev.toFixed(2), stake: kellyFraction(p1win, +pinH, bankroll) })
      }
      if (pinA) {
        const ev = evCalc(p2win, +pinA)
        if (ev > 0) picks.push({ label: p2, odds: +pinA, prob: p2win, ev: +ev.toFixed(2), stake: kellyFraction(p2win, +pinA, bankroll) })
      }

      return res.status(200).json({ p1, p2, e1, e2, surface, p1win: +p1win.toFixed(1), p2win, setProbs, picks })
    }

    return res.status(400).json({ error: 'Deporte no reconocido' })
  } catch (e) {
    return res.status(500).json({ error: e.message })
  }
}
